<?php
/**
 * Giriş: aşağı kaydırdıkça temelden bitmiş hale gelen yapı.
 *
 * İki mod:
 * - Video: temadaki assets/video/insaat.mp4 (Anıttepe inşaat videosu) ya da
 *   Özelleştir'den yüklenen video kaydırmayla kare kare ilerler.
 * - Fotoğraf: video yoksa bitmiş yapı fotoğrafı; önce teknik çizim, sonra zeminden
 *   yükselen kaba inşaat (gri), en sonda cephe ve renkler.
 *
 * @package MPA_Grup
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$video  = mpa_hero_video_sources();
$final  = mpa_hero_image_url();
$sketch = mpa_hero_sketch_url();
$phases = mpa_phases( (bool) $video );
$starts = implode( ',', wp_list_pluck( $phases, 'at' ) );
?>
<section class="mpa-build" id="insaat" aria-label="<?php esc_attr_e( 'İnşaat süreci', 'mpa-grup' ); ?>">
	<div class="mpa-build__stage is-intro" data-phases="<?php echo esc_attr( $starts ); ?>" data-mode="<?php echo $video ? 'video' : 'photo'; ?>" data-video="0.06,0.92">

		<div class="mpa-build__media" aria-hidden="true">
			<?php if ( $video ) : ?>
				<canvas class="mpa-build__blur" width="160" height="90"></canvas>
				<video class="mpa-build__video" poster="<?php echo esc_url( mpa_hero_video_poster() ); ?>" muted playsinline preload="auto">
					<?php foreach ( $video as $mime => $src ) : ?>
						<source src="<?php echo esc_url( $src ); ?>" type="<?php echo esc_attr( $mime ); ?>">
					<?php endforeach; ?>
				</video>
			<?php else : ?>
				<img class="mpa-build__layer mpa-build__sketch<?php echo $sketch ? '' : ' is-filtered'; ?>" src="<?php echo esc_url( $sketch ? $sketch : $final ); ?>" alt="" width="2000" height="1125" fetchpriority="high">
				<img class="mpa-build__layer mpa-build__rough" src="<?php echo esc_url( $final ); ?>" alt="" width="2000" height="1125">
				<img class="mpa-build__layer mpa-build__done" src="<?php echo esc_url( $final ); ?>" alt="" width="2000" height="1125">
				<div class="mpa-build__laser"></div>
			<?php endif; ?>
		</div>
		<div class="mpa-build__shade" aria-hidden="true"></div>

		<div class="mpa-build__copy">
			<div class="mpa-build__intro">
				<p class="kicker"><?php echo esc_html( mpa_opt( 'hero_eyebrow' ) ); ?></p>
				<h1 class="mpa-build__title"><?php echo mpa_kses_title( mpa_opt( 'hero_title' ) ); // phpcs:ignore ?></h1>
				<p class="mpa-build__lead"><?php echo esc_html( mpa_opt( 'hero_text' ) ); ?></p>
				<p class="mpa-build__cue"><span class="mpa-build__mouse" aria-hidden="true"></span><?php esc_html_e( 'Aşağı kaydırın', 'mpa-grup' ); ?></p>
			</div>

			<div class="mpa-build__phases" aria-live="polite">
				<p class="kicker"><?php esc_html_e( 'İnşaat süreci', 'mpa-grup' ); ?> <span class="kicker__count"><b data-hud="phase">1</b> / <?php echo (int) count( $phases ); ?></span></p>
				<ol class="phase-list">
					<?php foreach ( $phases as $i => $phase ) : ?>
						<li class="phase-item<?php echo 0 === $i ? ' is-active' : ''; ?>">
							<h2 class="phase-item__title"><span><?php echo esc_html( $phase['title'] ); ?></span></h2>
							<p class="phase-item__text"><?php echo esc_html( $phase['text'] ); ?></p>
						</li>
					<?php endforeach; ?>
				</ol>
			</div>

			<div class="mpa-build__final">
				<p class="kicker"><?php echo esc_html( mpa_opt( 'final_eyebrow' ) ); ?></p>
				<h2 class="mpa-build__title"><?php echo mpa_kses_title( mpa_opt( 'final_title' ) ); // phpcs:ignore ?></h2>
				<p class="mpa-build__lead"><?php echo esc_html( mpa_opt( 'final_text' ) ); ?></p>
				<div class="btn-row">
					<a class="btn btn--accent" href="<?php echo esc_url( mpa_url( 'projeler' ) ); ?>"><?php esc_html_e( 'Projelerimiz', 'mpa-grup' ); ?> <?php echo mpa_icon( 'arrow' ); // phpcs:ignore ?></a>
					<a class="btn btn--ghost-light" href="<?php echo esc_url( mpa_url( 'iletisim' ) ); ?>"><?php esc_html_e( 'Teklif Alın', 'mpa-grup' ); ?></a>
				</div>
			</div>
		</div>

		<div class="mpa-build__timeline" aria-hidden="true">
			<div class="timeline">
				<span class="timeline__track"><span class="timeline__fill" data-hud="bar"></span></span>
				<ol class="timeline__steps">
					<?php foreach ( $phases as $i => $phase ) : ?>
						<li class="timeline__step<?php echo 0 === $i ? ' is-active' : ''; ?>" style="left:<?php echo esc_attr( round( 100 * $i / ( count( $phases ) - 1 ), 3 ) ); ?>%"><i></i><span><?php echo esc_html( $phase['title'] ); ?></span></li>
					<?php endforeach; ?>
				</ol>
			</div>
			<span class="timeline__pct">%<b data-hud="pct">0</b></span>
		</div>

		<a class="mpa-build__skip" href="#hakkimizda"><?php esc_html_e( 'Geç', 'mpa-grup' ); ?> <?php echo mpa_icon( 'down' ); // phpcs:ignore ?></a>
	</div>
</section>
