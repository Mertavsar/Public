<?php
/**
 * MPA Grup İnşaat tema fonksiyonları.
 *
 * @package MPA_Grup
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'MPA_VERSION', '1.1.0' );
define( 'MPA_DIR', get_template_directory() );
define( 'MPA_URI', get_template_directory_uri() );

require MPA_DIR . '/inc/defaults.php';
require MPA_DIR . '/inc/template-tags.php';
require MPA_DIR . '/inc/post-types.php';
require MPA_DIR . '/inc/customizer.php';
require MPA_DIR . '/inc/contact.php';
require MPA_DIR . '/inc/setup-content.php';
require MPA_DIR . '/inc/pages.php';

/**
 * Tema destekleri ve menü konumları.
 */
function mpa_setup() {
	load_theme_textdomain( 'mpa-grup', MPA_DIR . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' ) );
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 150,
			'width'       => 900,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);

	register_nav_menus(
		array(
			'primary' => __( 'Ana Menü', 'mpa-grup' ),
			'footer'  => __( 'Alt Menü', 'mpa-grup' ),
		)
	);

	add_image_size( 'mpa-card', 960, 720, true );
}
add_action( 'after_setup_theme', 'mpa_setup' );

/**
 * Stil ve betikler.
 */
function mpa_assets() {
	wp_enqueue_style(
		'mpa-fonts',
		'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Poppins:wght@300;500;600;700;800&display=swap',
		array(),
		null
	);
	// Sürüm olarak dosyanın değişme zamanı: her güncellemede tarayıcı ve sunucu önbelleği yenilenir.
	wp_enqueue_style( 'mpa-style', get_stylesheet_uri(), array(), (string) filemtime( MPA_DIR . '/style.css' ) );

	$accent = sanitize_hex_color( mpa_opt( 'accent_color' ) );
	if ( $accent ) {
		wp_add_inline_style( 'mpa-style', ':root{--accent:' . $accent . ';}' );
	}

	wp_enqueue_script(
		'mpa-main',
		MPA_URI . '/assets/js/main.js',
		array(),
		(string) filemtime( MPA_DIR . '/assets/js/main.js' ),
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);
}
add_action( 'wp_enqueue_scripts', 'mpa_assets' );

/**
 * Google Fonts için ön bağlantı.
 *
 * @param array  $urls          URL listesi.
 * @param string $relation_type İlişki türü.
 * @return array
 */
function mpa_resource_hints( $urls, $relation_type ) {
	if ( 'preconnect' === $relation_type ) {
		$urls[] = 'https://fonts.googleapis.com';
		$urls[] = array(
			'href'        => 'https://fonts.gstatic.com',
			'crossorigin' => 'anonymous',
		);
	}
	return $urls;
}
add_filter( 'wp_resource_hints', 'mpa_resource_hints', 10, 2 );

/**
 * JS çalışıyorsa animasyonlar başlangıç durumundan açılır; çalışmıyorsa bitmiş bina görünür.
 */
function mpa_js_class() {
	// Giriş ekranı oturum başına bir kez gösterilir.
	echo "<script>(function(d){d.classList.add('js');try{if(sessionStorage.getItem('mpaSeen'))d.classList.add('seen');}catch(e){}})(document.documentElement);</script>\n";
}
add_action( 'wp_head', 'mpa_js_class', 1 );

/**
 * Site simgesi tanımlı değilse logodaki MPA işaretini kullan.
 */
function mpa_fallback_favicon() {
	if ( ! has_site_icon() ) {
		echo '<link rel="icon" type="image/png" href="' . esc_url( MPA_URI . '/assets/img/mark.png' ) . '">' . "\n";
	}
	echo '<meta name="theme-color" content="#0f161b">' . "\n";
}
add_action( 'wp_head', 'mpa_fallback_favicon', 5 );

/**
 * Ön sayfa için gövde sınıfı.
 *
 * @param array $classes Sınıflar.
 * @return array
 */
function mpa_body_class( $classes ) {
	if ( is_front_page() ) {
		$classes[] = 'mpa-home';
	}
	if ( mpa_has_image_hero() ) {
		$classes[] = 'has-hero';
	}
	return $classes;
}
add_filter( 'body_class', 'mpa_body_class' );

/**
 * Özet uzunluğu.
 *
 * @return int
 */
function mpa_excerpt_length() {
	return 26;
}
add_filter( 'excerpt_length', 'mpa_excerpt_length' );

// WordPress 6.7'nin "sizes=auto" eklentisi tarayıcıda görselin oranını yok sayar;
// sabit oranlı çerçevelerde (galeri, proje kartları) alttaki görseller sıfır yükseklikte kalır.
add_filter( 'wp_img_tag_add_auto_sizes', '__return_false' );

/**
 * Tema içeriği Türkçe olduğundan sayfa dili Türkçe işaretlenir; böylece büyük harfe
 * çevrilen başlıklarda "i" doğru şekilde "İ" olur (MİMARİ İMALAT).
 *
 * @param string $output Dil öznitelikleri.
 * @return string
 */
function mpa_language_attributes( $output ) {
	if ( 0 === strpos( get_locale(), 'tr' ) ) {
		return $output;
	}
	return preg_replace( '/lang="[^"]*"/', 'lang="tr"', $output );
}
add_filter( 'language_attributes', 'mpa_language_attributes' );

/**
 * Görselli giriş alanı olan sayfalar: üst menü bu sayfalarda görselin üzerinde şeffaf başlar.
 *
 * @return bool
 */
function mpa_has_image_hero() {
	return is_front_page()
		|| is_page( array( 'kurumsal', 'hizmetler' ) )
		|| is_post_type_archive( 'mpa_proje' )
		|| is_singular( 'mpa_proje' );
}

/**
 * Paylaşım önizlemesi (WhatsApp, LinkedIn, Facebook) ve arama motoru bilgileri.
 * Yoast / Rank Math / SEOPress gibi bir SEO eklentisi varsa onlara bırakılır.
 */
function mpa_meta_tags() {
	if ( defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'SEOPRESS_VERSION' ) || defined( 'AIOSEO_VERSION' ) ) {
		return;
	}
	$site  = mpa_opt( 'company_name' );
	$title = wp_get_document_title();
	$desc  = mpa_opt( 'hero_text' );
	$image = MPA_URI . '/assets/img/insaat-son.jpg';
	$url   = home_url( add_query_arg( array() ) );

	if ( is_singular() ) {
		$post = get_queried_object();
		$url  = get_permalink( $post );
		if ( has_excerpt( $post ) ) {
			$desc = get_the_excerpt( $post );
		}
		if ( has_post_thumbnail( $post ) ) {
			$image = get_the_post_thumbnail_url( $post, 'large' );
		}
	}
	if ( is_page( 'kurumsal' ) ) {
		$desc = wp_strip_all_tags( mpa_opt( 'about_title' ) );
	}

	$tags = array(
		'description'    => $desc,
		'og:type'        => is_singular( 'mpa_proje' ) ? 'article' : 'website',
		'og:site_name'   => $site,
		'og:locale'      => 'tr_TR',
		'og:title'       => $title,
		'og:description' => $desc,
		'og:url'         => $url,
		'og:image'       => $image,
		'twitter:card'   => 'summary_large_image',
	);
	foreach ( $tags as $key => $value ) {
		$attr = 0 === strpos( $key, 'og:' ) ? 'property' : 'name';
		printf( '<meta %1$s="%2$s" content="%3$s">' . "\n", esc_attr( $attr ), esc_attr( $key ), esc_attr( wp_strip_all_tags( $value ) ) );
	}

	$org = array(
		'@context'    => 'https://schema.org',
		'@type'       => 'GeneralContractor',
		'name'        => $site,
		'url'         => home_url( '/' ),
		'logo'        => MPA_URI . '/assets/img/logo.png',
		'image'       => MPA_URI . '/assets/img/insaat-son.jpg',
		'description' => mpa_opt( 'hero_text' ),
	);
	if ( mpa_opt( 'phone' ) ) {
		$org['telephone'] = mpa_opt( 'phone' );
	}
	if ( mpa_opt( 'email' ) ) {
		$org['email'] = mpa_opt( 'email' );
	}
	if ( mpa_opt( 'address' ) ) {
		$org['address'] = mpa_opt( 'address' );
	}
	$same = array_values( array_filter( array( mpa_opt( 'instagram' ), mpa_opt( 'linkedin' ), mpa_opt( 'facebook' ), mpa_opt( 'youtube' ) ) ) );
	if ( $same ) {
		$org['sameAs'] = $same;
	}
	if ( is_front_page() ) {
		echo '<script type="application/ld+json">' . wp_json_encode( $org, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . "</script>\n";
	}
}
add_action( 'wp_head', 'mpa_meta_tags', 2 );
